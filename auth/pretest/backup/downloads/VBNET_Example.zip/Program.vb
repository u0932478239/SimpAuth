﻿Imports System
Imports System.Drawing
Imports Colorful
Imports Console = Colorful.Console
Imports System.Windows.Forms

Namespace AkizaIO_Example

    ' Notice: This is a sample application, it has references and methods that are not necessary, they are
    '  only for use in design or in demonstration about more things you can do with the things offered by Akiza.IO!
    '  
    '  Documentation: https://docs.akiza.io/
    '  
    '  Initialize the initial configuration using this method, then remember to build it with ( name.Connect(); )
    ' 

    Friend Class Program
        Private Shared ReadOnly exampleApp As Akiza = New Akiza("Application name", "Application key", "Application version")

        Public Shared Sub Main()
            ' This is optional, the variable key can be found inside the panel of your application https://prnt.sc/uva3tg
            exampleApp.WithVariables("VMTD3G16G0BXMWCQO9G0SBPGA", True) ' true/false (enable/disable)

            ' Securely connecting to our API with your application data
            exampleApp.Connect()
            Console.Title = "Akiza.IO | The most secure authentication system on the market"
            Console.WriteLine(Environment.NewLine & " Akiza.IO | #1 Authentication System", Color.Beige)


            ' Application properties
            '  Console.WriteLine(App.Freemode); // bool
            '  Console.WriteLine(App.updaterLink); // string
            '  Console.WriteLine(App.Version); // string
            '  Console.WriteLine(App.devMode); // bool
            '  Console.WriteLine(App.enableUpdater); // bool
            '  Console.WriteLine(App.hashcheck); // bool
            '  Console.WriteLine(App.hashProgram); // string
            '  Console.WriteLine(App.HWIDLock); // bool
            ' 

            Console.WriteLine(" ------------------------------------------------", Color.Violet)
            Console.WriteLineFormatted(" {0}{1}{5}. Login", Color.PaleVioletRed, colorHelp)
            Console.WriteLineFormatted(" {0}{2}{5}. Register", Color.PaleVioletRed, colorHelp)
            Console.WriteLineFormatted(" {0}{3}{5}. AIO (Login only with License key) [Updated]", Color.PaleVioletRed, colorHelp)
            Console.WriteLineFormatted(" {0}{4}{5}. Extend subscription", Color.PaleVioletRed, colorHelp)
            Console.WriteLine(" ------------------------------------------------", Color.Violet)
            Console.Write(Environment.NewLine & " Option: ", Color.LightGray)
            Menu(Console.ReadLine())
        End Sub

        Public Shared Sub Menu(ByVal [option] As String)
            If Equals([option], "1") Then ' login
                Console.Write(Environment.NewLine & " Username: ", Color.LightGray)
                Dim username As String = Console.ReadLine()
                Console.Write(" Password: ", Color.LightGray)
                Dim password As String = Console.ReadLine()

                If exampleApp.Login(username, password) Then
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    myMethod()
                End If
            ElseIf Equals([option], "2") Then ' register
                Console.Write(Environment.NewLine & " Username: ", Color.LightGray)
                Dim username As String = Console.ReadLine()
                Console.Write(" Password: ", Color.LightGray)
                Dim password As String = Console.ReadLine()
                Console.Write(" License: ", Color.LightGray)
                Dim license As String = Console.ReadLine()

                If exampleApp.Register(username, password, license) Then
                    MessageBox.Show("Successfully registered!, Please log in", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Environment.Exit(0)
                End If
            ElseIf Equals([option], "3") Then ' login only with license key
                Console.Write(Environment.NewLine & " License: ", Color.LightGray)

                If exampleApp.licenseLogin(Console.ReadLine()) Then
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    myMethod()
                End If
            ElseIf Equals([option], "4") Then ' extend user subscription time
                Console.Write(Environment.NewLine & " Username: ", Color.LightGray)
                Dim username As String = Console.ReadLine()
                Console.Write(" Password: ", Color.LightGray)
                Dim password As String = Console.ReadLine()
                Console.Write(" License: ", Color.LightGray)
                Dim license As String = Console.ReadLine()

                If exampleApp.ExtendTime(username, password, license) Then
                    MessageBox.Show("Your user's time has been extended successfully!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Environment.Exit(0)
                End If
            Else
                MessageBox.Show("Invalid option", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Environment.Exit(0)
            End If

            Console.ReadLine()
        End Sub

        Public Shared Sub myMethod()
            While True
                Console.Clear()
                Console.WriteLine(Environment.NewLine & " Akiza.IO | Secure authentication system for .NET", Color.Beige)
                Console.WriteLine(" ------------------------------------------------", Color.Violet)
                Console.WriteLineFormatted(" {6} " & Info.Username, Color.PaleVioletRed, colorHelp)
                Console.WriteLineFormatted(" {7} " & Info.License, Color.PaleVioletRed, colorHelp)
                Console.WriteLineFormatted(" {8} " & Info.HWID, Color.PaleVioletRed, colorHelp)
                Console.WriteLineFormatted(" {9} " & Info.IP, Color.PaleVioletRed, colorHelp)
                Console.WriteLineFormatted(" {10} " & Info.Expires, Color.PaleVioletRed, colorHelp)
                Console.WriteLineFormatted(" {11} " & Info.Level, Color.PaleVioletRed, colorHelp) ' You can control the permissions between accounts by assigning a different level
                Console.WriteLine(" ------------------------------------------------", Color.Violet)
                Console.WriteLineFormatted(" {0}{1}{5}. Capture variable", Color.PaleVioletRed, colorHelp) ' (string) = exampleApp.captureVariable("variable name"); return the value
                Console.WriteLine(" ------------------------------------------------", Color.Violet)
                Console.Write(Environment.NewLine & " Option: ", Color.LightGray)
                Dim opt As Integer = Integer.Parse(Console.ReadLine())

                Select Case opt
                    Case 1
                        Console.Write(Environment.NewLine & " Variable Name: ")
                        Dim varName As String = Console.ReadLine()
                        MessageBox.Show($"Value: {exampleApp.captureVariable(varName)}", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Exit Select
                End Select
            End While
        End Sub



        ' This is not necessary, I just got creative
        Public Shared colorHelp As Formatter() = New Formatter() {New Formatter("[", Color.Gray), New Formatter("1", Color.MediumVioletRed), New Formatter("2", Color.MediumVioletRed), New Formatter("3", Color.MediumVioletRed), New Formatter("4", Color.MediumVioletRed), New Formatter("]", Color.Gray), New Formatter("Username:", Color.MediumVioletRed), New Formatter("License:", Color.MediumVioletRed), New Formatter("HWID:", Color.MediumVioletRed), New Formatter("IP:", Color.MediumVioletRed), New Formatter("Expires:", Color.MediumVioletRed), New Formatter("Level:", Color.MediumVioletRed)}
    End Class
End Namespace
