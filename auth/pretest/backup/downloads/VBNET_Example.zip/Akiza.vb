﻿#Region "usings"
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.IO
Imports System.Net
Imports System.Net.Http
Imports System.Net.Security
Imports System.Reflection
Imports System.Security
Imports System.Security.Cryptography
Imports System.Security.Cryptography.X509Certificates
Imports System.Security.Principal
Imports System.Text
Imports System.Web.Script.Serialization
Imports System.Windows.Forms
#End Region

' 
'  © 2020, Akiza.IO
'  Thank you for choosing Akiza.IO's services!
'  
'  You have the permissions to modify, edit, delete or add code in this class, 
'  as long as it is not with the intention of performing any evil act against 
'  our services, we recommend that you do not do it if you do not have knowledge 
'  about it, because you can risk the security of your application, 
'  if you have problems with this class or need support, you can contact us by mail, 
'  discord or by a message from the official website of Akiza.IO.
'  
'  support@akiza.io
'  https://discord.com/invite/UmJbzMd
'  
'  .NET version API Example: 1.0.5
'  
' 



Friend Class Akiza
    Public Shared Property GetControlVars As controlVars

    Public Sub New(ByVal appname As String, ByVal program_key As String, ByVal version As String)
        Auth.appName = appname
        Auth.App_Version = version
        Auth.App_Key = program_key
    End Sub

    Public Function WithVariables(ByVal variable_key As String, ByVal enable As Boolean) As Akiza
        controlVars.enable = enable
        controlVars.key = variable_key
        Return Me
    End Function

    Public Function Connect() As Akiza
        Call New Auth().Initialize()
        Return Me
    End Function

    Public Function Login(ByVal username As String, ByVal password As String) As Boolean
        If Not Auth.Initialized Then
            ' documentation: https://docs.akiza.io/
            MessageBox.Show("Badly executed program, you must initialize the application before logging in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End If

        If controlVars.enable Then
            controlVars.Handler.Add("password", password)
        End If

        Return Auth.Login(username, password)
    End Function

    Public Function Register(ByVal username As String, ByVal password As String, ByVal license As String) As Boolean
        If Not Auth.Initialized Then
            ' documentation: https://docs.akiza.io/
            MessageBox.Show("Badly executed program, you must initialize the application before logging in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End If

        Return Auth.Register(username, password, license)
    End Function

    Public Function ExtendTime(ByVal username As String, ByVal password As String, ByVal license As String) As Boolean
        If Not Auth.Initialized Then
            ' documentation: https://docs.akiza.io/
            MessageBox.Show("Badly executed program, you must initialize the application before logging in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End If

        Return Auth.ExtendTime(username, password, license)
    End Function

    Public Function captureVariable(ByVal variable_name As String) As String
        If controlVars.Vars.ContainsKey(variable_name) Then Return controlVars.Vars(variable_name)
        Return Auth.Variable_capture(variable_name)
    End Function

    Public Function licenseLogin(ByVal licenseKey As String) As Boolean
        If Not Auth.Initialized Then
            ' documentation: https://docs.akiza.io/
            MessageBox.Show("Badly executed program, you must initialize the application before logging in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End If

        Return Auth.licenseLogin(licenseKey)
    End Function
End Class

Public Class Info
    Public Shared Property Username As String
    Public Shared Property License As String
    Public Shared Property Level As String
    Public Shared Property Expires As String
    Public Shared Property IP As String
    Public Shared Property HWID As String
End Class

Public Class controlVars
    Public Shared Property enable As Boolean = False
    Public Shared Property key As String = String.Empty
    Public Shared Handler As Dictionary(Of String, String) = New Dictionary(Of String, String)()
    Public Shared Vars As Dictionary(Of String, String) = New Dictionary(Of String, String)()
End Class

Public Class App
    Public Shared Sub configuration(ByVal data As Dictionary(Of String, Object))
        Version = CStr(data("version"))
        updaterLink = If(Equals(CStr(data("updater_link")), Nothing), "Undefined", CStr(data("updater_link")))
        Enabled = Equals(CStr(data("enabled")), "1")
        HWIDLock = Equals(CStr(data("hwidlock")), "1")
        Freemode = Equals(CStr(data("freemode")), "1")
        devMode = Equals(CStr(data("devmode")), "1")
        hashcheck = Equals(CStr(data("hashcheck")), "1")
        enableUpdater = Equals(CStr(data("optionalupdater")), "1")
        If hashcheck Then hashProgram = CStr(data("hash"))
    End Sub

    Public Shared Property Version As String
    Public Shared Property Freemode As Boolean
    Public Shared Property Enabled As Boolean
    Public Shared Property hashcheck As Boolean
    Public Shared Property hashProgram As String = If(Equals(hashProgram, Nothing), "Undefined", hashProgram)
    Public Shared Property devMode As Boolean
    Public Shared Property HWIDLock As Boolean
    Public Shared Property enableUpdater As Boolean
    Public Shared Property updaterLink As String
End Class

Public Class Auth
    Public APIStartup As String = "https://akiza.io/api/handler/index.php"
    Public Shared ReadOnly Property certification_Key As String = "04B9102785F5213893B9B2E314B2199CA5A529D43519B731C7DDD1233705201315A866EC527DAC8D2FF28A37C1A2E64E24C018295D79F2951D74B14F9916D01293"
    Public Shared Property SessionStarted As Boolean
    Public Shared Property appName As String
    Public Shared Property AIO As Boolean
    Public Shared Property App_Key As String
    Public Shared Property App_Version As String
    Public Shared Property Initialized As Boolean = False
    Public Shared Property isLogged As Boolean = False
    Public Shared Property isRegistered As Boolean = False
    Public Shared Property isExtended As Boolean = False
    Public Shared Property Task_Done As Boolean = False
    Public Shared ReadOnly Property variables As controlVars
    Public Shared secure As SecureConnection = New SecureConnection()
    Public Shared GetSecurity As Security = New Security()

    Public Sub Initialize()
        secure.Start_Session()
        ServicePointManager.Expect100Continue = True
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12
        AddHandler secure.OnResponseReceived, AddressOf Secure_OnResponseReceiveds
        secure.EstablishSecureConnectionAsync()

        While Not secure.SecureConnectionEstablished
            Application.DoEvents()
        End While

        secure.End_Session()
        app_Initialize()
    End Sub

    Private Sub app_Initialize()
        secure.SendMessageSecureAsync(New JavaScriptSerializer().Serialize(New Dictionary(Of String, String) From {
            {"action", "initialize"},
            {"application_id", App_Key}
        }))

        While Not Task_Done
            Application.DoEvents()
        End While

        Task_Done = False
    End Sub

    Public Shared Function Login(ByVal username As String, ByVal password As String) As Boolean
        If secure.SecureConnectionEstablished Then
            secure.SendMessageSecureAsync(New JavaScriptSerializer().Serialize(New Dictionary(Of String, String) From {
                {"action", "login"},
                {"username", username},
                {"password", password},
                {"hwid", GetSecurity.HWIDPC()},
                {"date", Date.Now.ToString()},
                {"application_id", App_Key}
            }))

            While Not Task_Done
                Application.DoEvents()
            End While

            Task_Done = False
            Return isLogged
        Else
            Application.DoEvents()
        End If

        Return False
    End Function

    Public Shared Function Register(ByVal username As String, ByVal password As String, ByVal license As String) As Boolean
        If secure.SecureConnectionEstablished Then
            secure.SendMessageSecureAsync(New JavaScriptSerializer().Serialize(New Dictionary(Of String, String) From {
                {"action", "register"},
                {"username", username},
                {"password", password},
                {"license", license},
                {"ip", GetSecurity.IP()},
                {"hwid", GetSecurity.HWIDPC()},
                {"application_id", App_Key}
            }))

            While Not Task_Done
                Application.DoEvents()
            End While

            Task_Done = False
            Return isRegistered
        Else
            Application.DoEvents()
        End If

        Return False
    End Function

    Public Shared Function ExtendTime(ByVal username As String, ByVal password As String, ByVal license As String) As Boolean
        If secure.SecureConnectionEstablished Then
            secure.SendMessageSecureAsync(New JavaScriptSerializer().Serialize(New Dictionary(Of String, String) From {
                {"action", "extend_subscription"},
                {"username", username},
                {"password", password},
                {"license", license},
                {"hwid", GetSecurity.HWIDPC()},
                {"application_id", App_Key}
            }))

            While Not Task_Done
                Application.DoEvents()
            End While

            Task_Done = False
            Return isExtended
        Else
            Application.DoEvents()
        End If

        Return False
    End Function

    Public Shared Function Variable_capture(ByVal var_name As String) As String
        If Not isLogged Then
            MessageBox.Show("You must be logged in to capture variables!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        ElseIf Not controlVars.enable Then
            MessageBox.Show("If you have disabled the use of variables you will not be able to capture them!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

            If secure.SecureConnectionEstablished Then
                secure.SendMessageSecureAsync(New JavaScriptSerializer().Serialize(New Dictionary(Of String, String) From {
                    {"action", "var"},
                    {"username", Info.Username},
                    {"password", controlVars.Handler("password")},
                    {"hwid", GetSecurity.HWIDPC()},
                    {"application_id", App_Key},
                    {"variable_name", var_name},
                    {"variable_key", controlVars.key}
                }))

                While Not Task_Done
                    Application.DoEvents()
                End While

                Task_Done = False
                Return If(controlVars.Vars.ContainsKey(var_name), controlVars.Vars(var_name), "N/A")
            Else
                Application.DoEvents()
            End If
        End If

        Return "N/A"
    End Function

    Public Shared Function licenseLogin(ByVal license As String) As Boolean
        If secure.SecureConnectionEstablished Then
            secure.SendMessageSecureAsync(New JavaScriptSerializer().Serialize(New Dictionary(Of String, String) From {
                {"action", "licenseLogin"},
                {"license", license},
                {"hwid", GetSecurity.HWIDPC()},
                {"ip", GetSecurity.IP()},
                {"date", Date.Now.ToString()},
                {"application_id", App_Key}
            }))

            While Not Task_Done
                Application.DoEvents()
            End While

            Task_Done = False
            Return isLogged
        Else
            Application.DoEvents()
        End If

        Return False
    End Function



#Region "handling initialize response"
    Private Sub init_response(ByVal keyValuePairs As Dictionary(Of String, Object))
        Select Case GetSecurity.getMD5(CStr(keyValuePairs("status")))
            Case "260CA9DD8A4577FC00B7BD5810298076"
                App.configuration(keyValuePairs)

                If Not App.Enabled Then
                    MessageBox.Show("Program disabled by the administrator.", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Process.GetCurrentProcess().Kill()
                End If

                If App.enableUpdater Then
                    If Not Equals(App.Version, App.Version) Then
                        Console.ForegroundColor = ConsoleColor.Cyan
                        MessageBox.Show("There is a new update found! | [" & App.Version & "]", appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Console.ResetColor()
                        Dim page = If(Not App.updaterLink.Contains("http") OrElse Not App.updaterLink.Contains("://"), "https://" & App.updaterLink, App.updaterLink)
                        Process.Start(page)
                        Process.GetCurrentProcess().Kill()
                    End If
                End If

#Region "hash checker"
                If App.hashcheck Then
                    If String.IsNullOrEmpty(App.hashProgram) Then
                        MessageBox.Show("No hashes found to check application integrity!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Process.GetCurrentProcess().Kill()
                    ElseIf Not Equals(GetSecurity.program_hash(Assembly.GetEntryAssembly().Location), App.hashProgram) AndAlso Not App.devMode Then
                        MessageBox.Show("The hash of this application does not match the hash uploaded to the server!, if you think this is a mistake, contact your developer.", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Process.GetCurrentProcess().Kill()
                    ElseIf Not Equals(GetSecurity.program_hash(Assembly.GetEntryAssembly().Location), App.hashProgram) AndAlso App.devMode Then
                        File.AppendAllText("integrity.txt", GetSecurity.program_hash(Assembly.GetEntryAssembly().Location) & Environment.NewLine)
                        MessageBox.Show("The hash of this application was saved in the text : hash.txt !", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End If
#End Region

                If App.Freemode Then
                    MessageBox.Show("Free mode activated!", appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If

                Initialized = True
            Case "CB5E100E5A9A3E7F6D1FD97512215282" ' error
                MessageBox.Show(CStr(keyValuePairs("info")), appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
        End Select
    End Sub
#End Region

#Region "handling login response"
    Private Sub login_response(ByVal keyValuePairs As Dictionary(Of String, Object))
        Select Case CStr(keyValuePairs("status"))
            Case "incorrect_hwid"
                MessageBox.Show("The HWID is incorrect!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "hwid_reseted"
                MessageBox.Show("Your HWID has been reset!, please login again.", appName, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Process.GetCurrentProcess().Kill()
            Case "incorrect_details"
                MessageBox.Show("Invalid name or password!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "expired_time"
                MessageBox.Show("Your subscription time has expired!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "banned_user"
                MessageBox.Show("Your account is banned from this application!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "success"
                Info.Username = CStr(keyValuePairs("username"))
                Info.HWID = CStr(keyValuePairs("hwid"))
                Info.License = CStr(keyValuePairs("license"))
                Info.Level = CStr(keyValuePairs("level"))
                Info.IP = CStr(keyValuePairs("ip"))
                Info.Expires = CStr(keyValuePairs("expires"))

                If Not Equals(Info.HWID, GetSecurity.HWIDPC()) AndAlso App.HWIDLock Then
                    MessageBox.Show("Your HWID does not match!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Process.GetCurrentProcess().Kill()
                Else
                    isLogged = True
                End If
        End Select
    End Sub
#End Region

#Region "handling license key login response"
    Private Sub licenseLogin_response(ByVal keyValuePairs As Dictionary(Of String, Object))
        Select Case CStr(keyValuePairs("status"))
            Case "expired_time"
                MessageBox.Show("Your subscription time has expired!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "incorrect_hwid"
                MessageBox.Show("The HWID is incorrect!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "banned_user"
                MessageBox.Show("Your account is banned from this application!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "incorrect_details"
                MessageBox.Show("Invalid license key!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "success"
                Info.Username = CStr(keyValuePairs("license"))
                Info.HWID = CStr(keyValuePairs("hwid"))
                Info.License = CStr(keyValuePairs("license"))
                Info.Level = CStr(keyValuePairs("level"))
                Info.IP = CStr(keyValuePairs("ip"))
                Info.Expires = CStr(keyValuePairs("expires"))

                If Not Equals(Info.HWID, GetSecurity.HWIDPC()) AndAlso App.HWIDLock Then
                    MessageBox.Show("Your HWID does not match!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Process.GetCurrentProcess().Kill()
                Else
                    isLogged = True
                End If
        End Select
    End Sub
#End Region

#Region "handling register response  "
    Private Sub register_response(ByVal valuePairs As Dictionary(Of String, Object))
        Select Case CStr(valuePairs("status"))
            Case "username_used"
                MessageBox.Show("That username is already in use!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "max_quote" ' Having a subscription, don't even worry about this
                MessageBox.Show("Program owner has exceeded their max user quota.", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "invalid_license"
                MessageBox.Show("Your license is invalid!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "success"
                isRegistered = True
        End Select
    End Sub
#End Region

#Region "handling extend subscription time response  "
    Private Sub extendtime_response(ByVal valuePairs As Dictionary(Of String, Object))
        Select Case CStr(valuePairs("status"))
            Case "incorrect_details"
                MessageBox.Show("Invalid name or password!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "banned_user"
                MessageBox.Show("Your account is banned from this application!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "incorrect_hwid"
                MessageBox.Show("The HWID is incorrect!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "incorrect_license"
                MessageBox.Show("The license entered does not exist!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "success"
                isExtended = True
        End Select
    End Sub
#End Region

#Region "handling variable response"
    Private Sub var_response(ByVal keyValues As Dictionary(Of String, Object))
        Select Case CStr(keyValues("status"))
            Case "incorrect_details"
                MessageBox.Show("Invalid name or password!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Process.GetCurrentProcess().Kill()
            Case "success"
                If Not controlVars.Vars.ContainsKey(CStr(keyValues("var_name"))) Then controlVars.Vars.Add(CStr(keyValues("var_name")), CStr(keyValues("var_value")))
        End Select
    End Sub
#End Region

#Region "handling of all responses"
    Private Sub Secure_OnResponseReceiveds(ByVal sender As Object, ByVal e As ResponseReceivedEventArgs)
        Dim data = e.Response
        Dim result As Dictionary(Of String, Object) = TryCast(New JavaScriptSerializer().DeserializeObject(data), Dictionary(Of String, Object))
        Dim action = CStr(result("action"))

        If Equals(action, "banned_app") Then
            MessageBox.Show("This application is banned, please contact the developer.", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        ElseIf Equals(action, "failed_connection") OrElse Equals(action, "internal_error") Then
            MessageBox.Show("There was an error in the connection to the server!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        ElseIf Equals(action, "null_entry") Then
            MessageBox.Show("You must send all parameters to the server!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        ElseIf Equals(action, "unfound_application") Then
            MessageBox.Show("The application could not be found!", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        ElseIf Equals(action, "initialize") Then
            init_response(result)
            Task_Done = True
        ElseIf Equals(action, "login") Then
            login_response(result)
            Task_Done = True
        ElseIf Equals(action, "licenseLogin") Then
            licenseLogin_response(result)
            Task_Done = True
        ElseIf Equals(action, "register") Then
            register_response(result)
            Task_Done = True
        ElseIf Equals(action, "extend_subscription") Then
            extendtime_response(result)
            Task_Done = True
        ElseIf Equals(action, "var") Then
            var_response(result)
            Task_Done = True
        End If
    End Sub
#End Region

End Class

#Region "security application"
Public Class Security
    Public Function IP() As String
        Dim i = New HttpClient()
        Return i.GetStringAsync("http://icanhazip.com/").Result
    End Function

    Public Function HWIDPC() As String
        Return WindowsIdentity.GetCurrent().User.Value
    End Function

    ' Get the program hash
    Public Function program_hash(ByVal file As String) As String
        Using md5 = Cryptography.MD5.Create()

            Using stream = IO.File.OpenRead(file)
                Dim hash = md5.ComputeHash(stream)
                Return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant()
            End Using
        End Using
    End Function

    ' get the text hash
    Public Function getMD5(ByVal text As String) As String
        Dim arrBytTarget As Byte()
        Dim hash As MD5 = New MD5CryptoServiceProvider()
        arrBytTarget = hash.ComputeHash(Encoding.Default.GetBytes(text))
        Return BitConverter.ToString(arrBytTarget).Replace("-", "")
    End Function
End Class

#End Region

Public Class SecureConnection
    Inherits Auth
#Region "making secure connection"
    Private Property inUse As Boolean = False
    Private asyncResponse As String
    Private ReadOnly background As BackgroundWorker = New BackgroundWorker()
    Private ReadOnly eventSender As BackgroundWorker = New BackgroundWorker()
    Private ReadOnly httpControl As HttpControl = New HttpControl()
    Private ReadOnly RSACrypt As RSACryptography = New RSACryptography()
    Private ReadOnly AESCrypt As AESCryptography = New AESCryptography()
    Friend Event OnResponseReceived As ResponseReceivedHandler
    Friend Delegate Sub ResponseReceivedHandler(ByVal sender As Object, ByVal e As ResponseReceivedEventArgs)
    Friend Property SecureConnectionEstablished As Boolean

    Friend Sub New()
        SecureConnectionEstablished = False
        AddHandler background.DoWork, AddressOf background_DoWork
        AddHandler background.RunWorkerCompleted, AddressOf background_RunWorkerCompleted
        AddHandler eventSender.DoWork, AddressOf sender_DoWork
        AddHandler eventSender.RunWorkerCompleted, AddressOf sender_RunWorkerCompleted
    End Sub

#End Region

#Region "secure sessions"

    ' this is to get a secure connection between the client -> server
    Public Sub Start_Session()
        If SessionStarted Then
            MessageBox.Show("Session already started, closing for security reasons...", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        Else
            Dim hosts_Path = Environment.GetFolderPath(Environment.SpecialFolder.System) & "\drivers\etc\hosts"

            If File.Exists(hosts_Path) Then
                If File.ReadAllText(hosts_Path).Contains("akiza.io") Then
                    MessageBox.Show("DNS redirection found, closing the application...", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Environment.Exit(0)
                End If
            End If

            SessionStarted = True
        End If
    End Sub

    Public Sub End_Session()
        If Not SessionStarted Then
            MessageBox.Show("The session hasn't started yet, closing for security reasons...", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End If

        SessionStarted = False
    End Sub


#End Region

#Region "encryption connection "
    Private Sub background_RunWorkerCompleted(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        If Not SecureConnectionEstablished Then
            MessageBox.Show("It was not possible to establish a secure communication with the server.", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End If
    End Sub

    Private Sub background_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        Dim cert = httpControl.Post(APIStartup, "getkey=y")

        If String.IsNullOrEmpty(cert) Then
            MessageBox.Show("Invalid communication with the server ; null certificate", appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End If

        RSACrypt.LoadCertification(cert)
        AESCrypt.GenerateRandomKeys()
        Dim key = Utils.ToUrlSafeBase64(RSACrypt.Encrypt(AESCrypt.EncryptionKey))
        Dim iv = Utils.ToUrlSafeBase64(RSACrypt.Encrypt(AESCrypt.EncryptionIV))
        Dim result = httpControl.Post(APIStartup, "key=" & key & "&iv=" & iv)
        SecureConnectionEstablished = Equals(AESCrypt.Decrypt(result), "AES OK")
    End Sub

    Friend Sub EstablishSecureConnectionAsync()
        If Not background.IsBusy Then background.RunWorkerAsync()
    End Sub

    Friend Function SendMessageSecure(ByVal message As String) As String
        If SecureConnectionEstablished Then
            Dim encrypted = AESCrypt.Encrypt(message)
            Dim response = httpControl.Post(APIStartup, "data=" & encrypted)
            Return AESCrypt.Decrypt(response)
        End If

        Return "NOT CONNECTED"
    End Function


    ' Send an encrypted message and wait for a secure response
    Friend Sub SendMessageSecureAsync(ByVal message As String)
        If SecureConnectionEstablished AndAlso Not inUse Then eventSender.RunWorkerAsync(message)
    End Sub

    Private Sub sender_RunWorkerCompleted(ByVal sender As Object, ByVal e As RunWorkerCompletedEventArgs)
        inUse = False
        RaiseEvent OnResponseReceived(Me, New ResponseReceivedEventArgs(asyncResponse))
    End Sub

    Private Sub sender_DoWork(ByVal sender As Object, ByVal e As DoWorkEventArgs)
        inUse = True
        asyncResponse = SendMessageSecure(CStr(e.Argument))
    End Sub
#End Region
End Class

Friend Class ResponseReceivedEventArgs
    Friend Property Response As String

    Friend Sub New(ByVal response As String)
        Me.Response = response
    End Sub
End Class

Friend Class RSACryptography
    Private cert As X509Certificate2
    Private initialized As Boolean

    Friend Sub New()
        initialized = False
    End Sub

    Friend Sub LoadCertification(ByVal certificateText As String)
        Try
            cert = GetCertificate(certificateText)
            initialized = True
        Catch
            initialized = False
            MessageBox.Show("Could not connect properly with the server certificate.", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Process.GetCurrentProcess().Kill()
        End Try
    End Sub

    Private Shared Function GetCertificate(ByVal key As String) As X509Certificate2
        Try

            If key.Contains("-----") Then
                key = key.Split({"-----"}, StringSplitOptions.RemoveEmptyEntries)(1)
            End If

            key = key.Replace(Microsoft.VisualBasic.Constants.vbLf, "")
            Return New X509Certificate2(Convert.FromBase64String(key))
        Catch ex As Exception
            Throw New FormatException("The certificate key was not in the expected format.", ex)
        End Try
    End Function

    Friend Function Encrypt(ByVal message As Byte()) As Byte()
        If initialized Then
            Dim publicprovider = CType(cert.PublicKey.Key, RSACryptoServiceProvider)
            Return publicprovider.Encrypt(message, False)
        End If

        Throw New Exception("The RSA engine has not been initialized with a certificate yet.")
    End Function
End Class

Friend Class HttpControl
    Private ReadOnly cookies As CookieContainer

    Friend Sub New()
        cookies = New CookieContainer()
    End Sub

    Friend Function Post(ByVal url As String, ByVal data As String) As String
        Try
            Dim buffer = Encoding.ASCII.GetBytes(data)
            Dim request = CType(WebRequest.Create(url), HttpWebRequest)

            ' Send request
            request.Method = "POST"
            request.ContentType = "application/x-www-form-urlencoded"
            request.ContentLength = buffer.Length
            request.CookieContainer = cookies
            Dim postData = request.GetRequestStream()
            postData.Write(buffer, 0, buffer.Length)
            postData.Close()

            ' Get and return response
            Dim response = CType(request.GetResponse(), HttpWebResponse)
            Dim Answer = response.GetResponseStream()
            Dim lAnswer = New StreamReader(Answer)
            Return lAnswer.ReadToEnd()
        Catch ex As Exception
            Return "ERROR: " & ex.Message
        End Try
    End Function
End Class

Friend Class Utils
    Friend Shared Function ToUrlSafeBase64(ByVal input As Byte()) As String
        Return Convert.ToBase64String(input).Replace("+", "-").Replace("/", "_")
    End Function

    Friend Shared Function FromUrlSafeBase64(ByVal input As String) As Byte()
        Return Convert.FromBase64String(input.Replace("-", "+").Replace("_", "/"))
    End Function
End Class

Friend Class AESCryptography
    Friend ReadOnly Property EncryptionKey As Byte()
    Friend ReadOnly Property EncryptionIV As Byte()

    Friend Sub New()
        EncryptionKey = New Byte(31) {}
        EncryptionIV = New Byte(15) {}
        GenerateRandomKeys()
    End Sub

    Friend Sub GenerateRandomKeys()
        Dim random = New RNGCryptoServiceProvider()
        random.GetBytes(EncryptionKey)
        random.GetBytes(EncryptionIV)
    End Sub

    Friend Function Encrypt(ByVal plainText As String) As String
        Try
            Dim aes = New RijndaelManaged With {
                .Padding = PaddingMode.PKCS7,
                .Mode = CipherMode.CBC,
                .KeySize = 256,
                .Key = EncryptionKey,
                .IV = EncryptionIV
            }
            Dim encryptor = aes.CreateEncryptor(aes.Key, aes.IV)
            Dim msEncrypt = New MemoryStream()
            Dim csEncrypt = New CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write)
            Dim swEncrypt = New StreamWriter(csEncrypt)
            swEncrypt.Write(plainText)
            swEncrypt.Close()
            csEncrypt.Close()
            aes.Clear()
            Return Utils.ToUrlSafeBase64(msEncrypt.ToArray())
        Catch ex As Exception
            Throw New CryptographicException("Problem trying to encrypt.", ex)
        End Try
    End Function

    Friend Function Decrypt(ByVal cipherText As String) As String
        Try
            Dim aes = New RijndaelManaged With {
                .Padding = PaddingMode.PKCS7,
                .Mode = CipherMode.CBC,
                .KeySize = 256,
                .Key = EncryptionKey,
                .IV = EncryptionIV
            }
            Dim decryptor = aes.CreateDecryptor(aes.Key, aes.IV)
            Dim msDecrypt = New MemoryStream(Utils.FromUrlSafeBase64(cipherText))
            Dim csDecrypt = New CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read)
            Dim srDecrypt = New StreamReader(csDecrypt)
            Dim plaintext As String = srDecrypt.ReadToEnd()
            srDecrypt.Close()
            csDecrypt.Close()
            msDecrypt.Close()
            aes.Clear()
            Return plaintext
        Catch ex As Exception
            Throw New CryptographicException("Problem trying to decrypt.", ex)
        End Try
    End Function
End Class
