﻿using System;
using System.Drawing;
using Colorful;
using Console = Colorful.Console;
using System.Windows.Forms;
using System.Reflection;

namespace AkizaIO_Example
{

    /* Notice: This is a sample application, it has references and methods that are not necessary, they are
     * only for use in design or in demonstration about more things you can do with the things offered by Akiza.IO!
     * 
     * Documentation: https://docs.akiza.io/
     * 
     * Initialize the initial configuration using this method, then remember to build it with ( name.Connect(); )
     */

    class Program
    {


        static readonly Akiza exampleApp = 
            new Akiza("Application name", "Application Key/ID", "1.0");

        static void Main()
        {
            
            // Securely connecting to our API with your application data
            exampleApp.Connect();            

           
            Console.Title = "Akiza.IO | The most secure authentication system on the market";
            Console.WriteLine(Environment.NewLine + " Akiza.IO | #1 Authentication System", Color.Beige);


            /* Application properties
             * Console.WriteLine(App.Freemode); // bool
             * Console.WriteLine(App.updaterLink); // string
             * Console.WriteLine(App.Version); // string
             * Console.WriteLine(App.devMode); // bool
             * Console.WriteLine(App.enableUpdater); // bool
             * Console.WriteLine(App.hashcheck); // bool
             * Console.WriteLine(App.hashProgram); // string
             * Console.WriteLine(App.HWIDLock); // bool
             */

            Console.WriteLine(" ------------------------------------------------", Color.Violet);
            Console.WriteLineFormatted(" {0}{1}{5}. Login", Color.PaleVioletRed, colorHelp);
            Console.WriteLineFormatted(" {0}{2}{5}. Register", Color.PaleVioletRed, colorHelp);
            Console.WriteLineFormatted(" {0}{3}{5}. AIO (Login only with License key) [Updated]", Color.PaleVioletRed, colorHelp);
            Console.WriteLineFormatted(" {0}{4}{5}. Extend subscription", Color.PaleVioletRed, colorHelp);
            Console.WriteLine(" ------------------------------------------------", Color.Violet);
            Console.Write(Environment.NewLine + " Option: ", Color.LightGray);
            Menu(Console.ReadLine());            
        }
        public static void Menu(string option)
        {
            if (option == "1") // login
            {
                Console.Write(Environment.NewLine + " Username: ", Color.LightGray);
                string username = Console.ReadLine();
                Console.Write(" Password: ", Color.LightGray);
                string password = Console.ReadLine();

                if (exampleApp.Login(username, password))
                {
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    myMethod();
                }
            }
            else if (option == "2") // register
            {
                Console.Write(Environment.NewLine + " Username: ", Color.LightGray);
                string username = Console.ReadLine();
                Console.Write(" Password: ", Color.LightGray);
                string password = Console.ReadLine();
                Console.Write(" License: ", Color.LightGray);
                string license = Console.ReadLine();

                if (exampleApp.Register(username, password, license))
                {
                    MessageBox.Show("Successfully registered!, Please log in", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Environment.Exit(0);
                }
            }
            else if (option == "3") // login only with license key
            {
                Console.Write(Environment.NewLine + " License: ", Color.LightGray);
                if (exampleApp.licenseLogin(Console.ReadLine()))
                {
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    myMethod();
                }
            }
            else if (option == "4") // extend user subscription time
            {
                Console.Write(Environment.NewLine + " Username: ", Color.LightGray);
                string username = Console.ReadLine();
                Console.Write(" Password: ", Color.LightGray);
                string password = Console.ReadLine();
                Console.Write(" License: ", Color.LightGray);
                string license = Console.ReadLine();
                if (exampleApp.ExtendTime(username, password, license))
                {
                    MessageBox.Show("Your user's time has been extended successfully!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Environment.Exit(0);
                }
            }
            else
            {
                MessageBox.Show("Invalid option", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
            Console.ReadLine();
        }



        public static void myMethod()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine(Environment.NewLine + " Akiza.IO | Secure authentication system for .NET", Color.Beige);
                Console.WriteLine(" ------------------------------------------------", Color.Violet);
                Console.WriteLineFormatted(" {6} " + Info.Username, Color.PaleVioletRed, colorHelp);
                Console.WriteLineFormatted(" {7} " + Info.License, Color.PaleVioletRed, colorHelp);
                Console.WriteLineFormatted(" {8} " + Info.HWID, Color.PaleVioletRed, colorHelp);
                Console.WriteLineFormatted(" {9} " + Info.IP, Color.PaleVioletRed, colorHelp);
                Console.WriteLineFormatted(" {10} " + Info.Expires, Color.PaleVioletRed, colorHelp);
                Console.WriteLineFormatted(" {11} " + Info.Level, Color.PaleVioletRed, colorHelp); // You can control the permissions between accounts by assigning a different level
                Console.WriteLine(" ------------------------------------------------", Color.Violet);
                Console.WriteLineFormatted(" {0}{1}{5}. Capture variable", Color.PaleVioletRed, colorHelp); // (string) = exampleApp.captureVariable("variable name"); return the value
                Console.WriteLineFormatted(" {0}{2}{5}. Download file", Color.PaleVioletRed, colorHelp); // (string) = exampleApp.captureVariable("variable name"); return the value
                Console.WriteLine(" ------------------------------------------------", Color.Violet);
                Console.Write(Environment.NewLine + " Option: ", Color.LightGray);
                int opt = int.Parse(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.Write(Environment.NewLine + " Secure variable code: ");
                        string varCode = Console.ReadLine();
                        MessageBox.Show($"Value: {exampleApp.captureVariable(varCode)}", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;

                    case 2:
                        Console.Write(Environment.NewLine + " Secret download code: ");
                        string secretCode = Console.ReadLine();
                        Console.Write(" Path: ");
                        string path = Console.ReadLine();

                        /*
                         * If you want to download a file, you must save it along with
                         * the name it will have and the extension, for example, if you 
                         * upload a file with a .zip extension, in the path you must put 
                         * file-for-save.zip or "folder/file-for-save.zip"
                        */

                        if (exampleApp.downloadFile(secretCode, path))
                        {
                            MessageBox.Show("Successfully downloaded file!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }                            
                        else
                        {
                            MessageBox.Show("Error when downloading the file", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        break;
                }
            }
        }



        // This is not necessary, I just got creative
        public static Formatter[] colorHelp = new Formatter[]
        {
            new Formatter("[", Color.Gray),
            new Formatter("1", Color.MediumVioletRed),
            new Formatter("2", Color.MediumVioletRed),
            new Formatter("3", Color.MediumVioletRed),
            new Formatter("4", Color.MediumVioletRed),
            new Formatter("]", Color.Gray),
            new Formatter("Username:", Color.MediumVioletRed),
            new Formatter("License:", Color.MediumVioletRed),
            new Formatter("HWID:", Color.MediumVioletRed),
            new Formatter("IP:", Color.MediumVioletRed),
            new Formatter("Expires:", Color.MediumVioletRed),
            new Formatter("Level:", Color.MediumVioletRed)
        };
    }
}
