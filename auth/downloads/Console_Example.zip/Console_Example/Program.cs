﻿using System;
using System.Drawing;
using Console = Colorful.Console;
using System.Windows.Forms;
using System.Diagnostics;

namespace SimpAuth_Example
{
    class Program
    {
        static readonly SimpAuth api = new SimpAuth("Program Name", "Program Key", "Program Version (Default is 1.0)");
        /* Application properties
             * Console.WriteLine(App.Freemode); // bool
             * Console.WriteLine(App.updaterLink); // string
             * Console.WriteLine(App.Version); // string
             * Console.WriteLine(App.devMode); // bool
             * Console.WriteLine(App.enableUpdater); // bool
             * Console.WriteLine(App.hashcheck); // bool
             * Console.WriteLine(App.hashProgram); // string
             * Console.WriteLine(App.HWIDLock); // bool
             */
        static void Main()
        {
            api.Connect();            
            Console.Title = "SimpAuth | Console Example";
            Console.WriteLine(Environment.NewLine + " SimpAuth | Console Example", Color.Beige);
            Console.WriteLine(" ------------------------------------------------", Color.Violet);
            Console.WriteLineFormatted(" 1. Login", Color.PaleVioletRed);
            Console.WriteLineFormatted(" 2. Register", Color.PaleVioletRed);
            Console.WriteLineFormatted(" 3. All For One", Color.PaleVioletRed);
            Console.WriteLineFormatted(" 4. Extend subscription", Color.PaleVioletRed);
            Console.WriteLine(" ------------------------------------------------", Color.Violet);
            Console.Write(Environment.NewLine + " Option: ", Color.LightGray);
            Menu(Console.ReadLine());            
        }
        public static void Menu(string option)
        {
            if (option == "1") 
            {
                Console.Write(Environment.NewLine + " Username: ", Color.LightGray);
                string username = Console.ReadLine();
                Console.Write(" Password: ", Color.LightGray);
                string password = Console.ReadLine();

                if (api.Login(username, password))
                {
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CustomerMenu();
                }
            }
            else if (option == "2")
            {
                Console.Write(Environment.NewLine + " Username: ", Color.LightGray);
                string username = Console.ReadLine();
                Console.Write(" Password: ", Color.LightGray);
                string password = Console.ReadLine();
                Console.Write(" License: ", Color.LightGray);
                string license = Console.ReadLine();

                if (api.Register(username, password, license))
                {
                    MessageBox.Show("Successfully registered!, Please log in", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Application.Restart();
                    Process.GetCurrentProcess().Kill();
                }
            }
            else if (option == "3")
            {
                Console.Write(Environment.NewLine + " License: ", Color.LightGray);
                if (api.licenseLogin(Console.ReadLine()))
                {
                    MessageBox.Show("Successfully logged in!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CustomerMenu();
                }
            }
            else if (option == "4")
            {
                Console.Write(Environment.NewLine + " Username: ", Color.LightGray);
                string username = Console.ReadLine();
                Console.Write(" Password: ", Color.LightGray);
                string password = Console.ReadLine();
                Console.Write(" License: ", Color.LightGray);
                string license = Console.ReadLine();
                if (api.ExtendTime(username, password, license))
                {
                    MessageBox.Show("Your user's time has been extended successfully!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Environment.Exit(0);
                }
            }
            else
            {
                MessageBox.Show("Invalid option", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
            Console.ReadLine();
        }
        public static void CustomerMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine(Environment.NewLine + " SimpAuth | Console Example", Color.Beige);
                Console.WriteLine(" ------------------------------------------------", Color.Violet);
                Console.WriteLineFormatted(" Username: " + Info.Username, Color.PaleVioletRed);
                Console.WriteLineFormatted(" License Used: " + Info.License, Color.PaleVioletRed);
                Console.WriteLineFormatted(" HWID: " + Info.HWID, Color.PaleVioletRed);
                Console.WriteLineFormatted(" IP: " + Info.IP, Color.PaleVioletRed);
                Console.WriteLineFormatted(" Expiry: " + Info.Expires, Color.PaleVioletRed);
                Console.WriteLineFormatted(" Rank: " + Info.Level, Color.PaleVioletRed); // You can control the permissions between accounts by assigning a different level
                Console.WriteLine(" ------------------------------------------------", Color.Violet);
                Console.WriteLineFormatted(" 1. Capture variable", Color.PaleVioletRed); // (string) = api.captureVariable("variable name"); return the value
                Console.WriteLineFormatted(" 2. Download file", Color.PaleVioletRed); // (string) = api.captureVariable("variable name"); return the value
                Console.WriteLine(" ------------------------------------------------", Color.Violet);
                Console.Write(Environment.NewLine + " Option: ", Color.LightGray);
                int opt = int.Parse(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.Write(Environment.NewLine + " Secure variable code: ");
                        string varCode = Console.ReadLine();
                        MessageBox.Show($"Value: {api.captureVariable(varCode)}", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;

                    case 2:
                        Console.Write(Environment.NewLine + " Secret download code: ");
                        string secretCode = Console.ReadLine();
                        Console.Write(" Path: ");
                        string path = Console.ReadLine();

                        /*
                         * If you want to download a file, you must save it along with
                         * the name it will have and the extension, for example, if you 
                         * upload a file with a .zip extension, in the path you must put 
                         * file-for-save.zip or "folder/file-for-save.zip"
                        */

                        if (api.downloadFile(secretCode, path))
                        {
                            MessageBox.Show("Successfully downloaded file!", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Error when downloading the file", Auth.appName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        break;
                }
            }
        }
    }
}
